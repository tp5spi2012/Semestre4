err_t (*detruire)(objet_t **);
void (*afficher)(objet_t * const);
