#ifndef _OBJET_H_
#define _OBJET_H_

#include <commun.h>

/*
 * DEFINITION OBJET 
 */

typedef struct objet_s objet_t ;

struct objet_s 
{
#include <attributs_objet.h>
} ;

#endif
